/**
 * Facebook Smart Engagement Pro - Background Script
 * Facebook Auto Reaction Assistant
 * 
 * Chức năng chính:
 * - Smart reaction selection với thuật toán thông minh
 * - Safety features để tránh bị khóa tài khoản
 * - Human behavior simulation
 * - Activity limits và monitoring
 * - Trial system (3 days free)
 * - PRO subscription management
 */

(function () {
    'use strict';

    // ==================== CONFIGURATION ====================
    const CONFIG = {
        // Facebook API URLs
        GRAPH_URL: 'https://graph.facebook.com/v18.0/',
        MBASIC_URL: 'https://mbasic.facebook.com',
        M_URL: 'https://m.facebook.com',
        W3_URL: 'https://www.facebook.com',

        // Reaction types (theo thứ tự Facebook)
        REACTIONS: ['like', 'love', 'care', 'haha', 'wow', 'sad', 'angry'],

        // Thresholds - CẢI TIẾN ĐỘ CHÍNH XÁC
        MIN_REACTIONS: 5,            // Giảm xuống 5 để xử lý nhiều bài hơn
        MAX_LIKE_COUNT: 10,          // Tăng lên 10 để linh hoạt hơn
        REACTION_CONFIDENCE_THRESHOLD: 0.3,  // Ngưỡng tin cậy 30%

        // Delays (milliseconds) - AN TOÀN HƠN VỚI FACEBOOK
        DELAY_BETWEEN_REACTIONS: 5000,   // 5 giây (tăng từ 3s)
        DELAY_BETWEEN_POSTS: 3000,       // 3 giây (tăng từ 2s)
        DELAY_BETWEEN_REQUESTS: 2000,    // 2 giây (tăng từ 1s)
        RANDOM_DELAY_VARIANCE: 0.5,      // ±50% variance
        HUMAN_PAUSE_MIN: 15000,          // Pause tối thiểu 15s
        HUMAN_PAUSE_MAX: 45000,          // Pause tối đa 45s
        HUMAN_PAUSE_CHANCE: 0.2,         // 20% chance pause

        // PREMIUM UNLOCKED - TẤT CẢ TÍNH NĂNG
        PREMIUM_UNLOCKED: true,          // 🔓 MỞ KHÓA PREMIUM
        TRIAL_DAYS: 999999,              // Trial vô hạn
        FREE_REACTIONS_PER_DAY: 999999,  // Không giới hạn
        PRO_REACTIONS_PER_HOUR: 999999,  // Không giới hạn
        PRO_REACTIONS_PER_DAY: 999999,   // Không giới hạn

        // SAFETY LIMITS - AN TOÀN VỚI FACEBOOK
        MAX_REACTIONS_PER_HOUR: 15,      // Giảm xuống 15 (an toàn hơn)
        MAX_REACTIONS_PER_DAY: 80,       // Giảm xuống 80 (an toàn hơn)
        MAX_SESSION_DURATION: 2700000,   // 45 phút (giảm từ 60)
        MIN_BREAK_TIME: 300000,          // 5 phút nghỉ (tăng từ 2)
        WORKING_HOURS_ONLY: false,       // Hoạt động 24/7
        WEEKDAYS_ONLY: false,            // Hoạt động cả cuối tuần

        // ADVANCED SAFETY FEATURES
        ENABLE_SMART_TIMING: true,       // Thời gian thông minh
        ENABLE_PATTERN_RANDOMIZATION: true,  // Randomize patterns
        ENABLE_ACTIVITY_TRACKING: true,  // Theo dõi hoạt động
        SKIP_POST_CHANCE: 0.25           // 25% chance bỏ qua bài viết
    };

    // ==================== GLOBAL VARIABLES ====================
    let userToken = null;      // Facebook access token
    let userID = null;         // User ID từ cookie
    let dtsgToken = null;      // DTSG token cho requests
    let processedPosts = new Set();  // Danh sách bài viết đã xử lý
    let isRunning = false;     // Trạng thái đang chạy

    // SAFETY TRACKING - Theo dõi hoạt động để tránh bị phát hiện
    let activityTracker = {
        reactionsToday: 0,
        reactionsThisHour: 0,
        sessionStart: null,
        lastActivity: null,
        dailyReset: new Date().toDateString()
    };

    // ==================== TRIAL & SUBSCRIPTION SYSTEM ====================
    let userStatus = {
        isTrial: true,
        trialStart: null,
        isPro: false,
        licenseKey: null,
        expires: null,
        plan: 'free'
    };

    // ==================== INITIALIZATION ====================

    /**
     * Khởi tạo extension khi cài đặt
     */
    chrome.runtime.onInstalled.addListener(async (details) => {
        if (details.reason === 'install') {
            // Initialize trial system
            await initializeTrialSystem();

            // Mở trang chủ khi cài đặt lần đầu
            chrome.tabs.create({ url: 'https://www.facebook.com/dinhkhanhtung' });

            // Auto-start extension
            console.log('Extension installed - starting auto reaction...');
            setTimeout(() => {
                performAutoReaction();
            }, 5000); // Start after 5 seconds
        }
    });

    // Auto-start khi có tab Facebook được mở
    chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
        if (changeInfo.status === 'complete' && tab.url && tab.url.includes('facebook.com')) {
            console.log('Facebook tab detected - starting auto reaction...');
            setTimeout(() => {
                performAutoReaction();
            }, 3000); // Start after 3 seconds
        }
    });

    // ==================== SETTINGS MANAGEMENT ====================

    /**
     * Lấy cài đặt từ storage
     * @returns {Object} Cài đặt hiện tại
     */
    async function getSettings() {
        try {
            const result = await chrome.storage.local.get([
                'startup', 'ignore_fp', 'ignore_gr', 'blacklist', 'time_period',
                'working_hours_only', 'weekdays_only', 'max_reactions_hour',
                'max_reactions_day', 'delay_reactions'
            ]);

            return {
                startup: result.startup || false,
                ignore_fp: result.ignore_fp || false,
                ignore_gr: result.ignore_gr || false,
                blacklist: result.blacklist || '',
                time_period: result.time_period || 5,
                // Safety settings
                working_hours_only: result.working_hours_only || false,
                weekdays_only: result.weekdays_only || false,
                max_reactions_hour: result.max_reactions_hour || 20,
                max_reactions_day: result.max_reactions_day || 100,
                delay_reactions: result.delay_reactions || 3
            };
        } catch (error) {
            console.error('Error loading settings:', error);
            return {
                startup: false,
                ignore_fp: false,
                ignore_gr: false,
                blacklist: '',
                time_period: 5,
                // Safety settings defaults
                working_hours_only: false,
                weekdays_only: false,
                max_reactions_hour: 20,
                max_reactions_day: 100,
                delay_reactions: 3
            };
        }
    }

    // ==================== FACEBOOK AUTHENTICATION ====================

    /**
     * Lấy thông tin xác thực Facebook
     * @returns {boolean} True nếu thành công
     */
    async function getFacebookAuth() {
        try {
            console.log('Getting Facebook authentication...');

            // Lấy cookies Facebook
            const cookies = await chrome.cookies.getAll({ domain: '.facebook.com' });
            const c_user = cookies.find(c => c.name === 'c_user');
            const xs = cookies.find(c => c.name === 'xs');

            if (!c_user || !xs) {
                console.log('Facebook cookies not found');
                return false;
            }

            userID = c_user.value;
            console.log('User ID found:', userID);

            // Lấy access token từ Facebook
            const response = await fetch(`${CONFIG.M_URL}/composer/ocelot/async_loader/?publisher=feed`, {
                method: 'GET',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Accept-Encoding': 'gzip, deflate, br',
                    'DNT': '1',
                    'Connection': 'keep-alive',
                    'Upgrade-Insecure-Requests': '1'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const html = await response.text();

            // Trích xuất tokens từ HTML
            const dtsgMatch = html.match(/"DTSGInitialData",\[\],{"token":"([^"]+)"/);
            const tokenMatch = html.match(/"accessToken":"([^"]+)"/);

            if (dtsgMatch) {
                dtsgToken = dtsgMatch[1];
                console.log('DTSG token found');
            }

            if (tokenMatch) {
                userToken = tokenMatch[1];
                console.log('Access token found');
            }

            const success = !!(dtsgToken && userToken);
            console.log('Authentication result:', success);
            return success;

        } catch (error) {
            console.error('Error getting Facebook auth:', error);
            return false;
        }
    }

    // ==================== NEWS FEED PROCESSING ====================

    /**
     * Lấy danh sách bài viết từ news feed
     * @returns {Array} Danh sách bài viết
     */
    async function getNewsFeedPosts() {
        try {
            console.log('Fetching news feed posts...');

            const response = await fetch(`${CONFIG.MBASIC_URL}/stories.php`, {
                method: 'GET',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Accept-Encoding': 'gzip, deflate, br',
                    'DNT': '1',
                    'Connection': 'keep-alive'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const html = await response.text();
            const posts = [];

            // Parse bài viết từ HTML - cập nhật selectors cho Facebook 2025
            const postMatches = html.match(/<article[^>]*data-ft="([^"]*)"[^>]*>/g);

            if (postMatches) {
                postMatches.forEach(match => {
                    const dataFtMatch = match.match(/data-ft="([^"]*)"/);
                    if (dataFtMatch) {
                        try {
                            const dataFt = JSON.parse(dataFtMatch[1].replace(/&quot;/g, '"'));

                            // Chỉ lấy bài viết có đầy đủ thông tin
                            if (dataFt.top_level_post_id && dataFt.content_owner_id_new) {
                                posts.push({
                                    postId: dataFt.top_level_post_id,
                                    ownerId: dataFt.content_owner_id_new,
                                    pageId: dataFt.page_id,
                                    groupId: dataFt.group_id
                                });
                            }
                        } catch (e) {
                            console.log('Error parsing post data:', e);
                        }
                    }
                });
            }

            console.log(`Found ${posts.length} posts`);
            return posts;

        } catch (error) {
            console.error('Error getting news feed posts:', error);
            return [];
        }
    }

    // ==================== REACTION ANALYSIS ====================

    /**
     * Lấy số lượng reaction của một bài viết
     * @param {string} postId - ID bài viết
     * @returns {Array|null} Mảng số lượng reaction hoặc null nếu lỗi
     */
    async function getReactionCounts(postId) {
        try {
            // Tạo fields cho Graph API
            const fields = CONFIG.REACTIONS.map(reaction =>
                `reactions.type(${reaction.toUpperCase()}).limit(0).summary(total_count).as(reactions_${reaction})`
            ).join(',');

            const url = `${CONFIG.GRAPH_URL}${postId}?fields=${fields}&access_token=${userToken}`;

            const response = await fetch(url, {
                method: 'GET',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Accept': 'application/json'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const data = await response.json();

            // Trích xuất số lượng reaction
            const counts = CONFIG.REACTIONS.map(reaction =>
                data[`reactions_${reaction}`]?.summary?.total_count || 0
            );

            console.log(`Reaction counts for post ${postId}:`, counts);
            return counts;

        } catch (error) {
            console.error('Error getting reaction counts:', error);
            return null;
        }
    }

    /**
     * Chọn reaction phù hợp nhất dựa trên số lượng - THUẬT TOÁN CẢI TIẾN
     * @param {Array} counts - Mảng số lượng reaction
     * @returns {number} Index của reaction được chọn (-1 nếu bỏ qua)
     */
    function chooseReaction(counts) {
        const totalReactions = counts.reduce((sum, count) => sum + count, 0);

        // Bỏ qua nếu ít reaction
        if (totalReactions < CONFIG.MIN_REACTIONS) {
            console.log(`Skipping post - too few reactions (${totalReactions} < ${CONFIG.MIN_REACTIONS})`);
            return -1;
        }

        console.log('📊 Reaction analysis:', {
            total: totalReactions,
            breakdown: CONFIG.REACTIONS.map((r, i) => `${r}: ${counts[i]}`).join(', ')
        });

        // Tính phần trăm cho mỗi reaction
        const percentages = counts.map(count => count / totalReactions);

        // Tìm reaction có tỷ lệ cao nhất
        let maxPercentage = percentages[0];
        let bestReaction = 0;

        for (let i = 1; i < percentages.length; i++) {
            if (percentages[i] > maxPercentage) {
                maxPercentage = percentages[i];
                bestReaction = i;
            }
        }

        // Kiểm tra độ tin cậy - reaction phải chiếm ít nhất 30%
        if (maxPercentage < CONFIG.REACTION_CONFIDENCE_THRESHOLD) {
            console.log(`⚠️ Low confidence (${(maxPercentage * 100).toFixed(1)}% < ${CONFIG.REACTION_CONFIDENCE_THRESHOLD * 100}%), choosing most popular`);
            // Chọn reaction phổ biến nhất dựa trên số lượng tuyệt đối
            bestReaction = counts.indexOf(Math.max(...counts));
        }

        // Nếu like quá nhiều, chọn reaction khác có ý nghĩa hơn
        if (bestReaction === 0 && counts[0] > CONFIG.MAX_LIKE_COUNT) {
            console.log('💡 Too many likes, finding alternative reaction...');

            // Tìm reaction có số lượng cao thứ 2
            const sortedIndices = counts
                .map((count, index) => ({ count, index }))
                .sort((a, b) => b.count - a.count);

            // Chọn reaction thứ 2 nếu có ít nhất 20% số lượng của reaction đầu
            if (sortedIndices.length > 1 && sortedIndices[1].count >= sortedIndices[0].count * 0.2) {
                bestReaction = sortedIndices[1].index;
                console.log(`✓ Choosing ${CONFIG.REACTIONS[bestReaction]} (${counts[bestReaction]} reactions, ${(percentages[bestReaction] * 100).toFixed(1)}%)`);
            }
        }

        console.log(`🎯 Final choice: ${CONFIG.REACTIONS[bestReaction]} (${counts[bestReaction]} reactions, ${(percentages[bestReaction] * 100).toFixed(1)}%)`);
        return bestReaction;
    }

    // ==================== REACTION EXECUTION ====================

    /**
     * Thực hiện reaction cho một bài viết
     * @param {string} postId - ID bài viết
     * @param {number} reactionIndex - Index của reaction
     * @returns {boolean} True nếu thành công
     */
    async function reactToPost(postId, reactionIndex) {
        try {
            if (reactionIndex < 0 || reactionIndex >= CONFIG.REACTIONS.length) {
                console.log('Invalid reaction index:', reactionIndex);
                return false;
            }

            const reaction = CONFIG.REACTIONS[reactionIndex];
            console.log(`Reacting to post ${postId} with ${reaction}`);

            // METHOD 1: Sử dụng Facebook Graph API (Phương pháp chính)
            const success = await reactViaGraphAPI(postId, reaction);
            if (success) {
                console.log(`✓ Successfully reacted via Graph API: ${reaction}`);
                return true;
            }

            console.log('Graph API failed, trying fallback method...');

            // METHOD 2: Fallback - Sử dụng mbasic.facebook.com
            const fallbackSuccess = await reactViaMbasic(postId, reactionIndex);
            if (fallbackSuccess) {
                console.log(`✓ Successfully reacted via mbasic fallback: ${reaction}`);
                return true;
            }

            console.log('All reaction methods failed');
            return false;

        } catch (error) {
            console.error('Error reacting to post:', error);
            return false;
        }
    }

    /**
     * Thả reaction qua Facebook Graph API (Phương pháp chính)
     * @param {string} postId - ID bài viết
     * @param {string} reactionType - Loại reaction (like, love, haha, etc.)
     * @returns {boolean} True nếu thành công
     */
    async function reactViaGraphAPI(postId, reactionType) {
        try {
            if (!userToken) {
                console.log('No access token available');
                return false;
            }

            // Chuyển đổi reaction type sang định dạng Graph API
            const reactionTypeUpper = reactionType.toUpperCase();

            const url = `${CONFIG.GRAPH_URL}${postId}/reactions`;

            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                },
                body: JSON.stringify({
                    type: reactionTypeUpper,
                    access_token: userToken
                })
            });

            if (!response.ok) {
                const errorText = await response.text();
                console.error(`Graph API error (${response.status}):`, errorText);
                return false;
            }

            const data = await response.json();
            console.log('Graph API response:', data);

            return data.success === true || data.id !== undefined;

        } catch (error) {
            console.error('Error in reactViaGraphAPI:', error);
            return false;
        }
    }

    /**
     * Thả reaction qua mbasic.facebook.com (Phương pháp fallback)
     * @param {string} postId - ID bài viết
     * @param {number} reactionIndex - Index của reaction
     * @returns {boolean} True nếu thành công
     */
    async function reactViaMbasic(postId, reactionIndex) {
        try {
            console.log(`Trying mbasic method for post ${postId}, reaction index ${reactionIndex}`);

            // Bước 1: Lấy reaction picker page
            const pickerUrl = `${CONFIG.MBASIC_URL}/reactions/picker/?ft_id=${postId}`;

            const pickerResponse = await fetch(pickerUrl, {
                method: 'GET',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Referer': `${CONFIG.MBASIC_URL}/`,
                    'DNT': '1',
                    'Connection': 'keep-alive',
                    'Upgrade-Insecure-Requests': '1'
                },
                credentials: 'include'
            });

            if (!pickerResponse.ok) {
                console.error(`Picker page error: ${pickerResponse.status}`);
                return false;
            }

            const html = await pickerResponse.text();
            console.log('Picker page loaded, parsing reactions...');

            // Kiểm tra xem đã reaction chưa
            if (html.includes('Bỏ thích') || html.includes('Unlike') || html.includes('Remove reaction')) {
                console.log('Already reacted to this post, removing first...');
                // Tìm link để bỏ reaction
                const removeMatch = html.match(/<a href="([^"]*)"[^>]*>(?:Bỏ thích|Unlike|Remove)/i);
                if (removeMatch) {
                    const removeLink = removeMatch[1].replace(/&amp;/g, '&');
                    await fetch(`${CONFIG.MBASIC_URL}${removeLink}`, {
                        method: 'GET',
                        credentials: 'include'
                    });
                    await delay(1000); // Đợi 1 giây trước khi thả reaction mới
                }
            }

            // Bước 2: Tìm tất cả reaction links
            // Cập nhật regex để phù hợp với cấu trúc HTML mới của Facebook
            const reactionPatterns = [
                /<a href="(\/ufi\/reaction\/[^"]*ft_ent_identifier=[^"]*)"/g,
                /<a href="([^"]*reaction_type=[^"]*)"/g,
                /<a[^>]*href="([^"]*)"[^>]*aria-label="[^"]*(?:Like|Love|Care|Haha|Wow|Sad|Angry)[^"]*"/gi
            ];

            let reactionLinks = [];
            for (const pattern of reactionPatterns) {
                const matches = [...html.matchAll(pattern)];
                if (matches.length > 0) {
                    reactionLinks = matches.map(m => m[1].replace(/&amp;/g, '&'));
                    console.log(`Found ${reactionLinks.length} reaction links using pattern`);
                    break;
                }
            }

            if (reactionLinks.length === 0) {
                console.error('No reaction links found in picker page');
                console.log('HTML snippet:', html.substring(0, 500));
                return false;
            }

            if (reactionLinks.length <= reactionIndex) {
                console.error(`Reaction index ${reactionIndex} out of range (found ${reactionLinks.length} links)`);
                return false;
            }

            // Bước 3: Thực hiện reaction
            const reactionLink = reactionLinks[reactionIndex];
            const fullUrl = reactionLink.startsWith('http') ? reactionLink : `${CONFIG.MBASIC_URL}${reactionLink}`;

            console.log(`Executing reaction: ${fullUrl}`);

            const reactResponse = await fetch(fullUrl, {
                method: 'GET',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-US,en;q=0.5',
                    'Referer': pickerUrl,
                    'DNT': '1',
                    'Connection': 'keep-alive',
                    'Upgrade-Insecure-Requests': '1'
                },
                credentials: 'include',
                redirect: 'follow'
            });

            const success = reactResponse.ok;
            console.log(`Mbasic reaction result: ${success} (status: ${reactResponse.status})`);

            if (success) {
                const responseHtml = await reactResponse.text();
                // Kiểm tra xem có thông báo lỗi không
                if (responseHtml.includes('error') || responseHtml.includes('Error')) {
                    console.log('Response contains error message');
                    return false;
                }
            }

            return success;

        } catch (error) {
            console.error('Error in reactViaMbasic:', error);
            return false;
        }
    }

    // ==================== MAIN AUTO REACTION FUNCTION ====================

    /**
     * Hàm chính thực hiện auto reaction với SAFETY CHECKS
     */
    async function performAutoReaction() {
        if (isRunning) {
            console.log('Auto reaction already running, skipping...');
            return;
        }

        console.log('=== FB Smart Engagement Pro - Starting Auto Reaction ===');
        console.log('Current time:', new Date().toLocaleString());

        // SMART TIMING CHECK - Kiểm tra thời gian tự nhiên
        if (!isNaturalActivityTime()) {
            console.log('⏰ Not natural activity time - skipping this cycle');
            return;
        }

        console.log('Safety check result:', await isSafeToOperate());

        // SAFETY CHECK - Kiểm tra an toàn trước khi bắt đầu
        if (!(await isSafeToOperate())) {
            console.log('Safety check failed - pausing auto reaction');
            return;
        }

        isRunning = true;
        console.log('Starting auto reaction with safety features...');

        try {
            // Lấy cài đặt
            const settings = await getSettings();
            console.log('Settings loaded:', settings);

            // Kiểm tra xác thực
            if (!await getFacebookAuth()) {
                console.log('Facebook authentication failed');
                return;
            }

            // Lấy danh sách bài viết
            const posts = await getNewsFeedPosts();
            if (posts.length === 0) {
                console.log('No posts found');
                return;
            }

            // Xử lý từng bài viết với SAFETY CHECKS
            for (const post of posts) {
                if (!isRunning) {
                    console.log('Auto reaction stopped');
                    break;
                }

                // SAFETY CHECK - Kiểm tra an toàn cho mỗi bài viết
                if (!(await isSafeToOperate())) {
                    console.log('Safety limit reached - stopping auto reaction');
                    break;
                }

                const postKey = `${post.ownerId}_${post.postId}`;

                // Bỏ qua nếu đã xử lý
                if (processedPosts.has(postKey)) {
                    console.log(`Skipping already processed post: ${postKey}`);
                    continue;
                }

                // HUMAN BEHAVIOR SIMULATION - Mô phỏng hành vi người dùng
                if (!await simulateHumanBehavior()) {
                    console.log('Human behavior simulation - skipping post');
                    continue;
                }

                // Bỏ qua fanpage nếu cài đặt
                if (settings.ignore_fp && post.pageId) {
                    console.log(`Skipping fanpage post: ${postKey}`);
                    continue;
                }

                // Bỏ qua nhóm nếu cài đặt
                if (settings.ignore_gr && post.groupId) {
                    console.log(`Skipping group post: ${postKey}`);
                    continue;
                }

                // Bỏ qua blacklist
                if (settings.blacklist && settings.blacklist.includes(post.ownerId)) {
                    console.log(`Skipping blacklisted user: ${post.ownerId}`);
                    continue;
                }

                console.log(`Processing post: ${postKey}`);

                // Lấy số lượng reaction
                const counts = await getReactionCounts(post.postId);
                if (!counts) {
                    await delay(CONFIG.DELAY_BETWEEN_POSTS);
                    continue;
                }

                // Chọn reaction
                const reactionIndex = chooseReaction(counts);
                if (reactionIndex >= 0) {
                    // Thực hiện reaction với SAFETY TRACKING
                    const success = await reactToPost(post.postId, reactionIndex);
                    if (success) {
                        console.log(`Successfully reacted to post ${post.postId} with ${CONFIG.REACTIONS[reactionIndex]}`);
                        processedPosts.add(postKey);

                        // CẬP NHẬT ACTIVITY TRACKER - Theo dõi hoạt động
                        updateActivityTracker();
                        console.log(`Activity: ${activityTracker.reactionsToday}/${CONFIG.MAX_REACTIONS_PER_DAY} today, ${activityTracker.reactionsThisHour}/${CONFIG.MAX_REACTIONS_PER_HOUR} this hour`);
                    }
                }

                // Delay giữa các bài viết
                await delay(CONFIG.DELAY_BETWEEN_POSTS);
            }

        } catch (error) {
            console.error('Error in auto reaction:', error);
        } finally {
            isRunning = false;

            // RESET SESSION nếu đã hết thời gian
            if (activityTracker.sessionStart) {
                const sessionDuration = Date.now() - activityTracker.sessionStart;
                if (sessionDuration > CONFIG.MAX_SESSION_DURATION) {
                    console.log('Session duration exceeded - resetting session');
                    resetSession();
                }
            }

            console.log('Auto reaction completed with safety features');
        }
    }

    // ==================== SAFETY FUNCTIONS ====================

    /**
     * Kiểm tra xem có thể hoạt động an toàn không
     * @returns {boolean} True nếu an toàn
     */
    async function isSafeToOperate() {
        const now = new Date();
        const settings = await getSettings();

        // Kiểm tra giờ làm việc
        if (settings.working_hours_only) {
            const hour = now.getHours();
            if (hour < 9 || hour > 18) {
                console.log('Outside working hours - pausing activity');
                return false;
            }
        }

        // Kiểm tra ngày trong tuần
        if (settings.weekdays_only) {
            const day = now.getDay();
            if (day === 0 || day === 6) { // Sunday or Saturday
                console.log('Weekend - pausing activity');
                return false;
            }
        }

        // Kiểm tra giới hạn reactions
        if (activityTracker.reactionsToday >= settings.max_reactions_day) {
            console.log('Daily reaction limit reached');
            return false;
        }

        if (activityTracker.reactionsThisHour >= settings.max_reactions_hour) {
            console.log('Hourly reaction limit reached');
            return false;
        }

        // Kiểm tra session duration
        if (activityTracker.sessionStart) {
            const sessionDuration = Date.now() - activityTracker.sessionStart;
            if (sessionDuration > CONFIG.MAX_SESSION_DURATION) {
                console.log('Session duration limit reached');
                return false;
            }
        }

        return true;
    }

    /**
     * Cập nhật activity tracker
     */
    function updateActivityTracker() {
        const now = new Date();
        const today = now.toDateString();

        // Reset daily counter nếu ngày mới
        if (today !== activityTracker.dailyReset) {
            activityTracker.reactionsToday = 0;
            activityTracker.dailyReset = today;
        }

        // Reset hourly counter nếu giờ mới
        const oneHourAgo = Date.now() - (60 * 60 * 1000);
        if (!activityTracker.lastActivity || activityTracker.lastActivity < oneHourAgo) {
            activityTracker.reactionsThisHour = 0;
        }

        // Cập nhật counters
        activityTracker.reactionsToday++;
        activityTracker.reactionsThisHour++;
        activityTracker.lastActivity = Date.now();

        // Bắt đầu session nếu chưa có
        if (!activityTracker.sessionStart) {
            activityTracker.sessionStart = Date.now();
        }
    }

    /**
     * Reset session sau khi nghỉ
     */
    function resetSession() {
        activityTracker.sessionStart = null;
        console.log('Session reset - ready for new session');
    }

    /**
     * Lấy random delay để tránh pattern detection
     * @param {number} baseDelay - Delay cơ bản
     * @returns {number} Random delay
     */
    function getRandomDelay(baseDelay) {
        const randomFactor = 0.7 + Math.random() * 0.6; // 0.7x to 1.3x
        return Math.floor(baseDelay * randomFactor);
    }

    /**
     * Mô phỏng hành vi người dùng - NÂNG CAO ĐỘ AN TOÀN
     */
    async function simulateHumanBehavior() {
        // Random pause giữa các hoạt động - TĂNG TẦN SUẤT
        if (Math.random() < CONFIG.HUMAN_PAUSE_CHANCE) {
            const pauseTime = CONFIG.HUMAN_PAUSE_MIN + Math.random() * (CONFIG.HUMAN_PAUSE_MAX - CONFIG.HUMAN_PAUSE_MIN);
            console.log(`👤 Human behavior: pausing for ${(pauseTime / 1000).toFixed(1)}s`);
            await delay(pauseTime);
        }

        // Random skip posts - MÔ PHỎNG NGƯỜI DÙNG THẬT
        if (Math.random() < CONFIG.SKIP_POST_CHANCE) {
            console.log('👤 Human behavior: skipping post (not interested)');
            return false;
        }

        // Random micro-delays - Mô phỏng đọc bài viết
        const readTime = 1000 + Math.random() * 3000; // 1-4 giây
        console.log(`👤 Human behavior: reading post for ${(readTime / 1000).toFixed(1)}s`);
        await delay(readTime);

        return true;
    }

    /**
     * Kiểm tra thời gian hoạt động có tự nhiên không
     */
    function isNaturalActivityTime() {
        if (!CONFIG.ENABLE_SMART_TIMING) return true;

        const now = new Date();
        const hour = now.getHours();

        // Giảm hoạt động vào ban đêm (0-6h)
        if (hour >= 0 && hour < 6) {
            return Math.random() < 0.1; // 10% chance hoạt động
        }

        // Tăng hoạt động vào giờ cao điểm (12-14h, 18-22h)
        if ((hour >= 12 && hour < 14) || (hour >= 18 && hour < 22)) {
            return Math.random() < 0.9; // 90% chance hoạt động
        }

        // Bình thường các giờ khác
        return Math.random() < 0.7; // 70% chance hoạt động
    }

    // ==================== UTILITY FUNCTIONS ====================

    /**
     * Delay function với random factor
     * @param {number} ms - Milliseconds to delay
     */
    function delay(ms) {
        const randomMs = getRandomDelay(ms);
        return new Promise(resolve => setTimeout(resolve, randomMs));
    }

    // ==================== EVENT LISTENERS ====================

    /**
     * Xử lý alarm (chu kỳ chạy)
     */
    chrome.alarms.onAlarm.addListener((alarm) => {
        if (alarm.name === 'autoReaction') {
            console.log('Alarm triggered - starting auto reaction');
            performAutoReaction();
        } else if (alarm.name === 'activationCheck') {
            console.log('Activation check alarm triggered');
            checkActivationStatus();
        }
    });

    /**
     * Xử lý message từ popup
     */
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        console.log('Message received:', request);

        if (request.action === 'start') {
            // Bắt đầu auto reaction
            chrome.alarms.clear('autoReaction');
            const timePeriod = request.timePeriod || 5;
            chrome.alarms.create('autoReaction', {
                delayInMinutes: 1,
                periodInMinutes: timePeriod
            });
            console.log(`Auto reaction started with ${timePeriod} minute interval`);
            sendResponse({ success: true });

        } else if (request.action === 'stop') {
            // Dừng auto reaction
            chrome.alarms.clear('autoReaction');
            isRunning = false;
            console.log('Auto reaction stopped');
            sendResponse({ success: true });

        } else if (request.action === 'status') {
            // Lấy trạng thái
            chrome.alarms.get('autoReaction').then(alarm => {
                sendResponse({
                    running: !!alarm,
                    isProcessing: isRunning
                });
            });
            return true; // Giữ message channel mở cho async response
        }
    });

    // ==================== AUTO-START ====================

    /**
     * Tự động khởi động nếu cài đặt
     */
    getSettings().then(settings => {
        if (settings.startup) {
            console.log('Auto-starting extension...');
            chrome.alarms.create('autoReaction', {
                delayInMinutes: 1,
                periodInMinutes: settings.time_period
            });
        }
    });

    // ==================== AUTO-ACTIVATION POLLING ====================

    /**
     * Start auto-activation polling
     */
    function startActivationPolling() {
        console.log('Starting auto-activation polling...');
        chrome.alarms.create('activationCheck', {
            delayInMinutes: 0.5, // Check every 30 seconds
            periodInMinutes: 0.5
        });
    }

    /**
     * Stop auto-activation polling
     */
    function stopActivationPolling() {
        chrome.alarms.clear('activationCheck');
        console.log('Auto-activation polling stopped');
    }

    console.log('Smart Auto Reaction for FB background script loaded');

    // Start auto-activation polling
    startActivationPolling();

    // ==================== TRIAL & SUBSCRIPTION FUNCTIONS ====================

    /**
     * Khởi tạo hệ thống trial - PREMIUM UNLOCKED
     */
    async function initializeTrialSystem() {
        try {
            // 🔓 AUTO-ACTIVATE PREMIUM FOR ALL USERS
            userStatus = {
                isTrial: false,
                trialStart: Date.now(),
                isPro: true,  // ✅ PREMIUM ACTIVATED
                licenseKey: 'PREMIUM-UNLOCKED-' + Date.now(),
                expires: Date.now() + (999999 * 24 * 60 * 60 * 1000), // Vô hạn
                plan: 'premium_lifetime'
            };

            await chrome.storage.local.set({ userStatus });
            console.log('🔓 Premium features unlocked for all users!');
            console.log('✅ License:', userStatus.licenseKey);
            console.log('✅ Plan:', userStatus.plan);

        } catch (error) {
            console.error('Error initializing trial system:', error);
            // Fallback: vẫn activate premium nếu có lỗi
            userStatus = {
                isTrial: false,
                isPro: true,
                licenseKey: 'PREMIUM-UNLOCKED-FALLBACK',
                plan: 'premium_lifetime'
            };
        }
    }

    /**
     * Kiểm tra trạng thái trial - ALWAYS PREMIUM
     */
    async function checkTrialStatus() {
        // 🔓 ALWAYS RETURN PREMIUM STATUS
        userStatus.isPro = true;
        userStatus.plan = 'premium_lifetime';
        await chrome.storage.local.set({ userStatus });
        console.log('✅ Premium status verified');
        return true;
    }

    /**
     * Kiểm tra quyền sử dụng tính năng - ALWAYS RETURN TRUE
     */
    function canUseFeature(feature) {
        // 🔓 ALL FEATURES UNLOCKED
        return true;
    }

    /**
     * Kiểm tra giới hạn reactions - PREMIUM LIMITS
     */
    function getReactionLimits() {
        // 🔓 PREMIUM LIMITS FOR ALL USERS (but still safe)
        return {
            perHour: CONFIG.MAX_REACTIONS_PER_HOUR,  // 15/giờ (an toàn)
            perDay: CONFIG.MAX_REACTIONS_PER_DAY     // 80/ngày (an toàn)
        };
    }

    /**
     * Kích hoạt PRO license
     */
    async function activateProLicense(licenseKey, plan, expires) {
        userStatus.isPro = true;
        userStatus.isTrial = false;
        userStatus.licenseKey = licenseKey;
        userStatus.expires = expires;
        userStatus.plan = plan;

        await chrome.storage.local.set({ userStatus });
        console.log('PRO license activated:', licenseKey);

        // Notify popup about PRO activation
        chrome.runtime.sendMessage({
            type: 'PRO_ACTIVATED',
            plan: plan
        });
    }

    /**
     * Validate license với server
     */
    async function validateLicense() {
        if (!userStatus.licenseKey) {
            return false;
        }

        try {
            const response = await fetch('https://fb-smart-engagement-api.vercel.app/api/validate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    licenseKey: userStatus.licenseKey,
                    userId: userID,
                    deviceId: await getDeviceId()
                })
            });

            if (response.ok) {
                const data = await response.json();
                return data.valid && data.expires > Date.now();
            }
        } catch (error) {
            console.error('License validation failed:', error);
        }

        return false;
    }

    /**
     * Lấy device ID
     */
    async function getDeviceId() {
        const result = await chrome.storage.local.get(['deviceId']);
        if (!result.deviceId) {
            const deviceId = 'device_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
            await chrome.storage.local.set({ deviceId });
            return deviceId;
        }
        return result.deviceId;
    }

    /**
     * Mở trang thanh toán
     */
    function openPaymentPage() {
        chrome.tabs.create({
            url: 'https://fb-smart-engagement-backend.vercel.app/?userId=' + userID
        });
    }

    /**
     * Check activation status from server
     */
    async function checkActivationStatus() {
        if (!userID) {
            console.log('No user ID available for activation check');
            return;
        }

        try {
            console.log('Checking activation status for user:', userID);
            const response = await fetch(`https://fb-smart-engagement-backend.vercel.app/api/users/activation-status/${userID}`);

            if (response.ok) {
                const data = await response.json();
                console.log('Activation status response:', data);

                if (data.success && data.activated) {
                    console.log('Activation detected! Auto-activating PRO...');
                    await autoActivatePro(data.licenseKey, data.plan);
                }
            }
        } catch (error) {
            console.error('Error checking activation status:', error);
        }
    }

    /**
     * Auto-activate PRO license
     */
    async function autoActivatePro(licenseKey, plan) {
        try {
            console.log('Auto-activating PRO with license:', licenseKey);

            const response = await fetch('https://fb-smart-engagement-backend.vercel.app/api/users/activate-license', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    userId: userID,
                    licenseKey: licenseKey
                })
            });

            if (response.ok) {
                const data = await response.json();
                console.log('Auto-activation response:', data);

                if (data.success) {
                    // Activate PRO in extension
                    await activateProLicense(licenseKey, plan, data.expires);
                    console.log('PRO auto-activated successfully!');

                    // Notify popup
                    chrome.runtime.sendMessage({
                        type: 'PRO_AUTO_ACTIVATED',
                        plan: plan,
                        licenseKey: licenseKey
                    });
                }
            }
        } catch (error) {
            console.error('Error auto-activating PRO:', error);
        }
    }

    // ==================== MESSAGE HANDLERS ====================

    // Handle messages from popup
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.type === 'GET_USER_STATUS') {
            sendResponse(userStatus);
        } else if (request.type === 'OPEN_PAYMENT') {
            openPaymentPage();
        } else if (request.type === 'ACTIVATE_LICENSE') {
            activateProLicense(request.licenseKey, request.plan, request.expires);
        }
    });

})();